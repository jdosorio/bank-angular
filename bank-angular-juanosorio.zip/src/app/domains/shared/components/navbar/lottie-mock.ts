
import { Component } from '@angular/core';

@Component({
  selector: 'ngx-lottie',
  template: '<div></div>',
})
export class LottieMockComponent {}
